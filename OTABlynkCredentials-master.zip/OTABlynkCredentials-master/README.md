# OTABlynkCredentials
This repository contains the library and code for entering your wifi and blynk credentials over the air using your web browser


Necesaary Changes that you have to do in the code
1. Change the Erasing button pin according to your project. This button will be used to erase the data saved in EEPROM.
2. Enter SSID name and password for your ESP board acting as a server. 

Above mentioned changes will differ according to different user. If you want to see how to use this library for your Blynk projects,
then kindly watch this full tutorial video,

https://youtu.be/cjGBlEVPGBI
